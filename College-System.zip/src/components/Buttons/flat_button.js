import React from 'react'
import { Button } from 'react-md'

const FlatButton = (props) => {
    return (
        <div>
            <Button {...props}></Button>
        </div>
    )
}
export default FlatButton
