const password = {
    password: null
}

export default password;
