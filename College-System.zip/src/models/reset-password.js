const reset = {
    mobile: null,
    otp: null
}

export default reset;
