const signin = {
    number: null ,
    password: null,
}

export default signin;