const reports = {
    "size": "1000000",
    // "from_date" : "",
    // "to_date" : "",
    "districtId": "",
    "departmentId": "",
    "serviceId": "",
    "fromDate":"06-12-2017"
}

export default reports;
