const keys = {
    USER_PREFERENCE :{
      USER_ID : "uHT^xoA%y#&nsXC",
      TOKEN: "AkjsUTjtxhg",
      PERMISSIONS: "qBIL#0^TW*lsHSb",
      IS_SUPERUSER: "Q!mFIW%JihGKjhu",
      USER_NAME: "QWScq1O&&XNyna",
      EMAIL: "em",
      PASSWORD: "ps",
      NODAL_OFFICER_DATA: "Swvyf&id^oEWREP",
      ISSUER_DIST : 'J7g%bh8u&nO45FUp',
      PREVIOUS_PAGE : 'P@8$x71F6qA*#vv',
      SEARCH_QUERY : 'Sg$axf1S61A8FvX',
      SCROLL_POSITION : 'Hme25n!&yW6HDjX'
    },
    APP_PREFERENCE : {
      IS_TOKEN_EXPIRED : "EibN%InLbS&REdL",
      CURRENT_APPLICATION_STATUS : "K@qwOpP0kW0TUtF",
      PREVIOUS_COUNT : "C&hjs&Vd34^VJhs",
    }
}

export default keys;
