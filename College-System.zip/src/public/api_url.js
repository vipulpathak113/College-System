// window.HOST = 'http://13.127.50.63/'
window.HOST = 'http://staging.network.co.in/'